package com.shivam.foodyshoody

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class RegisterPage : AppCompatActivity() {
    lateinit var btn_register:Button
    lateinit var txt_mail_address: EditText
    lateinit var txt_mobilenumber: EditText
    lateinit var txtChoose_pass:EditText
    lateinit var txtpaswrd:EditText
    val mobilenum = "9305184757"
    val MobilenumAgain = "8188999903"
    val paswrd1 = "siy@"
    val paswrd2 = "r@m@"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_page)
        title="Register Yourself"
        btn_register=findViewById(R.id.btn_register)
        txt_mail_address=findViewById(R.id.txt_mail_address)
        txt_mobilenumber=findViewById(R.id.txt_mobilenumber)
        txtpaswrd=findViewById(R.id.txtpaswrd)
        txtChoose_pass=findViewById((R.id.txtChoose_pass))

        btn_register.setOnClickListener{

            val phonenum=txt_mobilenumber.text.toString()
            val pass=txtChoose_pass.text.toString()
            val pass1=txtpaswrd.text.toString()
            if(phonenum==mobilenum || phonenum==MobilenumAgain) {
                if (pass == pass1 && (pass == paswrd1 || pass == paswrd2)) {
                    val intent = Intent(this@RegisterPage, Menu::class.java)
                    startActivity(intent)
                } else {
                    Toast.makeText(this@RegisterPage, "Invalid Information", Toast.LENGTH_LONG)
                        .show()
                }
            }
        }
    }
}