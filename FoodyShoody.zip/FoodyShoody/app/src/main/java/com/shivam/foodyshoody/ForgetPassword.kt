package com.shivam.foodyshoody

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class ForgetPassword : AppCompatActivity() {
    lateinit var btnLoginNext: Button
    lateinit var txt_second_mobile_num: EditText
    lateinit var txtPassword_scnd: EditText
    val mobileNumberAgain = "9305184757"
    val MobilenumberAgain = "8188999903"
    val passwrd1 = "siyar@m"
    val passwrd2 = "shiv@m13"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget_pass)
        title = "Forget Password"
        btnLoginNext = findViewById(R.id.btnLoginNext)
        txt_second_mobile_num = findViewById(R.id.txt_second_mobile_num)
        txtPassword_scnd = findViewById(R.id.txtPassword_scnd)

        btnLoginNext.setOnClickListener {

            val mobilenumber = txt_second_mobile_num.text.toString()
            val password = txtPassword_scnd.text.toString()
            if (mobilenumber == mobileNumberAgain || mobilenumber == MobilenumberAgain) {
                if (password == passwrd1 || password == passwrd2) {
                    val intent = Intent(this@ForgetPassword, Menu::class.java)
                    startActivity(intent)
                } else {
                    Toast.makeText(this@ForgetPassword, "Invalid Information", Toast.LENGTH_LONG)
                        .show()
                }
            }
        }
    }
}
