package com.shivam.foodyshoody

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {

    lateinit var txtmobile_num:EditText
    lateinit var txtPassword:EditText
    lateinit var btnlogin:Button
    lateinit var txt_frgtpass:TextView
    lateinit var signin:TextView
    lateinit var btn_register:Button

    val mobile_number="9305184757"
    val scndmobilenumber="8188999903"
    val pass= "siyar@m"
    val pass2="shiv@m13"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "Food Runner"
        txtmobile_num = findViewById(R.id.txtmobile_num)
        txtPassword = findViewById(R.id.txtPassword)
        btnlogin = findViewById(R.id.btnlogin)
        txt_frgtpass = findViewById(R.id.txt_frgtpass)
        signin = findViewById(R.id.signin)
        //While clicking on forget password
        txt_frgtpass.setOnClickListener {
            val intent = Intent(this@LoginActivity, ForgetPassword::class.java)
            startActivity(intent)
        }
        // While clicking omn sign up
        signin.setOnClickListener {
            val intent = Intent(this@LoginActivity, RegisterPage::class.java)
            startActivity(intent)
        }


        btnlogin.setOnClickListener {
            val mobilenumber = txtmobile_num.text.toString()
            val password = txtPassword.text.toString()
            if (mobilenumber == mobile_number || mobilenumber == scndmobilenumber) {
                if (password == pass || password == pass2) {
                    val intent = Intent(this@LoginActivity, Menu::class.java)
                    startActivity(intent)
                } else {
                    Toast.makeText(this@LoginActivity, "Incorrect Information", Toast.LENGTH_LONG)
                        .show()
                }
            }
                }
            }
        }


